package com.example.paddy.barfinderapp2;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.content.Context;
import android.content.ContentValues;
import android.util.Pair;

import java.util.ArrayList;

public class MyDBHandler extends SQLiteOpenHelper {

    //various vars for the column names, table names etc.
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "BelfastBarFinderApp";
    public static final String TABLE_USER = "usertable";
    public static final String TABLE_BAR = "bars";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String TABLE_POSTCODES = "postcodes";
    public static final String COLUMN_POSTID = "_id";
    public static final String COLUMN_POSTCODES = "postcode";
    public static final String COLUMN_BARNAMES = "barNames";
    public static final String COLUMN_BARADDRESS = "barAddress";
    public static final String COLUMN_PHONENUMBER = "phoneNumbers";
    public static final String COLUMN_EMAILS = "emails";
    public SQLiteDatabase db;

    //pass database information to the superclass
    public MyDBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    /**
     * on create set up the three database tables
     *
     * @param db
     */
    @Override
    public void onCreate(SQLiteDatabase db) {

        //create the user table
        String query = "CREATE TABLE " + TABLE_USER + "(" + COLUMN_EMAILS + " TEXT, " +
                COLUMN_PASSWORD + " TEXT, " + COLUMN_USERNAME + " TEXT PRIMARY KEY " + " );";

        //create the postcode table
        String query2 = "CREATE TABLE " + TABLE_POSTCODES + " (" + COLUMN_POSTID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_POSTCODES + " TEXT, " + COLUMN_USERNAME +
                " TEXT, FOREIGN KEY (" + COLUMN_USERNAME + ") REFERENCES " + TABLE_USER + "(" + COLUMN_USERNAME + ")ON DELETE CASCADE);";

        //create the bar table
        String query3 = "CREATE TABLE " + TABLE_BAR + "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_BARNAMES + " TEXT, " + COLUMN_BARADDRESS + " TEXT, " + COLUMN_POSTCODES + " TEXT, "
                + COLUMN_PHONENUMBER + " TEXT);";

        //execute the three queries to create user tables
        db.execSQL(query);
        db.execSQL(query2);
        db.execSQL(query3);
    }

    /**
     * Gets the username and password associated with a given email
     *
     * @param email
     * @return
     */
    public String[] getPasswordAndUsername(String email) {

        //get readableDatabase
        db = this.getReadableDatabase();
        //query to select required rows from user table
        String query = "select emails, username, password from " + TABLE_USER;
        //use the query
        Cursor cursor = db.rawQuery(query, null);

        String a;
        String[] b = {"none", "none"};

        //if the cursor hits a row containing the email, get the username and password
        if (cursor.moveToFirst()) {
            do {
                a = cursor.getString(0);


                if (a.equals(email)) {
                    b[0] = cursor.getString(1);
                    b[1] = cursor.getString(2);
                    break;
                }
            }
            while (cursor.moveToNext());
        }
        db.close();
        return b;


    }

    /**
     * gets the login details used to test whether the user can log in
     *
     * @param userName
     * @return
     */
    public String getLoginVerification(String userName) {
        db = this.getReadableDatabase();
        String query = "select username, password from " + TABLE_USER;
        Cursor cursor = db.rawQuery(query, null);

        String a, b;
        b = "not found";

        //if the cursor hits a row containing the username, get the password
        if (cursor.moveToFirst()) {
            do {
                a = cursor.getString(0);


                if (a.equals(userName)) {
                    b = cursor.getString(1);
                    break;
                }
            }
            while (cursor.moveToNext());
        }
        db.close();
        //returns the password
        return b;
    }

    /**
     * Gets the postcodes associated with a username from the db
     *
     * @param userName
     * @return
     */
    public ArrayList<String> getPostcode(String userName) {
        db = this.getReadableDatabase();
        String query = "select username, postcode from " + TABLE_POSTCODES;
        Cursor cursor = db.rawQuery(query, null);

        String a;
        //arrayList to hold the postcodes
        ArrayList<String> b = new ArrayList<>();


        //if cursor hits a row containing the username, store the postcode in b
        if (cursor.moveToFirst()) {
            do {
                a = cursor.getString(0);


                if (a.equals(userName)) {
                    b.add(cursor.getString(1));

                }
            }
            while (cursor.moveToNext());
        }
        db.close();

        //returns the postcodes
        return b;
    }

    /**
     * Deletes a postcode from the database based on the postcode and the username associated with the postcode
     * (this will work in future)
     *
     * @param postcode
     * @param username
     */
    public void deletePostcode(String postcode, String username) {
        String[] whereArgs = {postcode, username};
        db.delete(TABLE_POSTCODES, "Where postcode = ? and username = ?", whereArgs);

    }

    /**
     * Checks whether the input email is already in the db
     *
     * @param rEmail
     * @return
     */
    public String checkEmailStatus(String rEmail) {
        db = this.getReadableDatabase();
        String query = "select emails from " + TABLE_USER;
        Cursor cursor = db.rawQuery(query, null);

        String a, b;
        b = "not found";

        // if the cursor hits a row containing the email then set b as found
        if (cursor.moveToFirst()) {
            do {
                a = cursor.getString(0);


                if (a.equals(rEmail)) {
                    b = "found";
                    break;
                }
            }
            while (cursor.moveToNext());
        }
        db.close();
        //returns whether or not the email has been found
        return b;
    }

    /**
     * checks the username status, whether its already in the db
     *
     * @param username
     * @return
     */
    public String checkUsernameStatus(String username) {
        db = this.getReadableDatabase();
        String query = "select username from " + TABLE_USER;
        Cursor cursor = db.rawQuery(query, null);

        String a, b;
        b = "not found";

        //if the cursor hit a row containing the username set b to found
        if (cursor.moveToFirst()) {
            do {
                a = cursor.getString(0);


                if (a.equals(username)) {
                    b = "found";
                    break;
                }
            }
            while (cursor.moveToNext());
        }
        db.close();

        //returns whether or not the username is in the db
        return b;
    }


    /**
     * on upgrade drop these tables if they exist
     *
     * @param db
     * @param oldVersion
     * @param newVersion
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_POSTCODES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BAR);
        onCreate(db);
    }

    /**
     * Add a new user to the db
     *
     * @param user
     */
    public void addUser(User user) {
        ContentValues values = new ContentValues();

        //associate values with their columns
        values.put(COLUMN_EMAILS, user.get_email());
        values.put(COLUMN_USERNAME, user.get_username());
        values.put(COLUMN_PASSWORD, user.get_password());

        //get writable db
        SQLiteDatabase db = getWritableDatabase();

        //insert the values into the user table
        db.insert(TABLE_USER, null, values);
        db.close();
    }

    /**
     * add a new bar to the db
     *
     * @param bar
     */
    public void addBar(Bar bar) {
        ContentValues values = new ContentValues();

        //associate values with their columns
        values.put(COLUMN_BARNAMES, bar.get_barName());
        values.put(COLUMN_BARADDRESS, bar.get_address());
        values.put(COLUMN_POSTCODES, bar.get_postcode());
        values.put(COLUMN_PHONENUMBER, bar.get_phoneNumber());

        //get writable db
        SQLiteDatabase db = getWritableDatabase();

        //insert the values into the bar table
        db.insert(TABLE_BAR, null, values);

        //for debugging...
        System.out.println("addBar");
        db.close();
    }

    /**
     * method gets arraylist pair of bar names and postcodes
     *
     * @return
     */
    public ArrayList<Pair<String, String>> getBarNamePostcode() {
        db = this.getReadableDatabase();
        String query = "select postcode, barNames from " + TABLE_BAR;
        Cursor cursor = db.rawQuery(query, null);

        //the arraylist pair
        ArrayList<Pair<String, String>> b = new ArrayList<Pair<String, String>>();

        //gets all the barnames and postcodes
        if (cursor.moveToFirst()) {
            do {
                b.add(new Pair(cursor.getString(0), cursor.getString(1)));
            } while (cursor.moveToNext());
        }
        db.close();
        return b;
    }

    /**
     * method gets arraylist pair of bar address and phone numbers
     *
     * @return
     */
    public ArrayList<Pair<String, String>> getBarAddressTelephone() {
        db = this.getReadableDatabase();
        String query = "select barAddress, phoneNumbers from " + TABLE_BAR;
        Cursor cursor = db.rawQuery(query, null);

        //the arraylist pair
        ArrayList<Pair<String, String>> b = new ArrayList<Pair<String, String>>();

        //gets all the bar addresses and phone numbers
        if (cursor.moveToFirst()) {
            do {
                b.add(new Pair(cursor.getString(0), cursor.getString(1)));
            } while (cursor.moveToNext());
        }
        db.close();
        return b;
    }

    /**
     * adds a new postcode to the db
     * @param postcode
     */
    public void addPostcode(PostCodes postcode) {
        ContentValues values = new ContentValues();

        //associates values with their columns
        values.put(COLUMN_POSTCODES, postcode.get_postCode());
        values.put(COLUMN_USERNAME, postcode.get_username());

        //gets writable db
        SQLiteDatabase db = getWritableDatabase();

        //insert the values into the postcode table
        db.insert(TABLE_POSTCODES, null, values);
        db.close();
    }


}
