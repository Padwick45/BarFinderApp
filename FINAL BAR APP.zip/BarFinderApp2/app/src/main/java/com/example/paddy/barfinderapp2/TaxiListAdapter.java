package com.example.paddy.barfinderapp2;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.lang.Object;import java.lang.Override;import java.lang.String;import java.util.List;

/**
 * Created by Aaron on 17/04/2016.
 */
public class TaxiListAdapter extends BaseAdapter {

    // Default constructor
    private Context mContext;
    private List<Taxi> mTaxiList;

    // Constructor with args
    public TaxiListAdapter(Context mContext, List<Taxi> mTaxiList) {
        this.mContext = mContext;
        this.mTaxiList = mTaxiList;
    }

    //Retrieves the amount of taxis to be added to the listView
    @Override
    public int getCount() {
        return mTaxiList.size();
    }

    //Retrieves the position for each variable to be placed
    @Override
    public Object getItem(int position) {
        return mTaxiList.get(position);
    }

    //Gets the ID for each item in the listView
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = View.inflate(mContext, R.layout.content_taxi_list, null);
        //Gets the name of the taxi company from the array
        TextView taxiName = (TextView)v.findViewById(R.id.taxi_name);
        //Gets the phone number of the taxi company from the array
        TextView taxiPhone = (TextView)v.findViewById(R.id.taxi_phone);
        //Gets the address of the taxi company from the array
        TextView taxiAddress = (TextView)v.findViewById(R.id.taxi_address);

        //Set text for TextView
        //Gets the position for adding the name of taxi
        taxiName.setText(mTaxiList.get(position).getName());
        //Gets the position for adding phone number of taxi company
        taxiPhone.setText(String.valueOf(mTaxiList.get(position).getPhone()));
        //Gets the position of the address for the taxi company
        taxiAddress.setText(mTaxiList.get(position).getAddress());

        //Sets an ID for each taxi and it's information
        v.setTag(mTaxiList.get(position).getId());

        // Returns the view
        return v;
    }
}
