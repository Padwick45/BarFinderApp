package com.example.paddy.barfinderapp2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;
import java.lang.Override;

public class WhitesTavern extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_whites_tavern);

        //TextView displaying the bar's address
        TextView t = (TextView) findViewById(R.id.whitesTavernAddress);
        //Sets the text of the textview to the bar's address
        t.setText(Html.fromHtml(
                "Address: " +
                        "<a href=\"https://www.google.co.uk/maps/place/Whites+Tavern/@54.6000781,-5.9306017,17z/data=!3m1!4b1!4m2!3m1!1s0x4861085699f0c193:0x6222e635f154070b\">" +
                        "Whites Tavern, Winecellar Entry, Belfast" +
                        "</a>"));
        //Converts text into a clickable link
        t.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
