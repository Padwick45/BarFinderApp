package com.example.paddy.barfinderapp2;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

/**
 * class used to authenticate the email
 */
class EmailAuthenticator extends Authenticator {

    //variables to store the username and password
    String user;
    String pass;

    /**
     * Default constructor
     *
     * @param username
     * @param password
     */
    public EmailAuthenticator(String username, String password) {
        super();
        this.user = username;
        this.pass = password;
    }

    /**
     * Authenticates the password
     *
     * @return
     */
    public PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(user, pass);
    }
}
