package com.example.paddy.barfinderapp2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * class to control the forgotPasswordActivity
 */
public class ForgotPasswordActivity extends AppCompatActivity {

    //variables to store the values we need
    private String emailForgotPassword, password, username;
    private EditText forgotPasswordET;
    private String[] passwordUsernameArray;

    /**
     * called on create, sets up activity and vars
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        setUpVars();
    }

    /**
     * When the user clicks the send password button this method is called.
     * It sends an email containing the user's username and password
     *
     * @param view
     */
    public void sendEmail(View view) {

        //object of the EmailSender
        EmailSender emailSender = new EmailSender();

        //get the database handler
        MyDBHandler myDBHandler = new MyDBHandler(this, null, null, 1);

        emailForgotPassword = forgotPasswordET.getText().toString();
        System.out.println(emailForgotPassword);
        //returns an array containing the username and password associated with the email account in the database
        passwordUsernameArray = myDBHandler.getPasswordAndUsername(emailForgotPassword);

        //close the db
        myDBHandler.close();

        //get the username and password from the array
        username = passwordUsernameArray[0];
        password = passwordUsernameArray[1];

        //IF... the username and password strings are empty then let the user no that their email address
        //is not on our records.
        //ELSE... send the user and email containing their details. Let them know the email has been sent.
        if (username.equals("none") || password.equals("none")) {

            //message to let the user know that their email address isn't registered
            Toast.makeText(getApplicationContext(), "There is no account registered to this email address",
                    Toast.LENGTH_LONG).show();
        } else {
            //uses email sender class to send an email to the user containing their details
            emailSender.sendEmail(emailForgotPassword, password, username);

            //message to let the user know that the email has sent successfully
            Toast.makeText(getApplicationContext(), "Email sent",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Sets up the variables
     */
    public void setUpVars() {
        forgotPasswordET = (EditText) findViewById(R.id.forgotPasswordET);

    }
}
