package com.example.paddy.barfinderapp2;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SearchBars extends AppCompatActivity {

    //xml references
    private EditText postCode;
    public String username;
    private CheckBox postcodeCheckBox;
    private TextView savedPostcodesTV;
    private Spinner postcodeSpinner;
    public String selected;
    private Button searchSavePostcodeButton;


    /**
     * on create set up the activity depending on whether or not the user is logged in
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_bars);

        //sets up vars
        setUpVars();

        //gets username from intent
        Intent startingIntent = getIntent();
        username = startingIntent.getStringExtra("username");

        //if user isn't logged in set postcode favourites ui invisible
        if (username == null) {
            uiForNonUsers();
        } else {
            //getsPostcodes
            getPostcodes();
        }
    }

    /**
     * sets up the vars
     */
    public void setUpVars() {
        postcodeCheckBox = (CheckBox) findViewById(R.id.postcodeCheckBox);
        postcodeSpinner = (Spinner) findViewById(R.id.postcodeSpinner);
        searchSavePostcodeButton = (Button) findViewById(R.id.searchSavedPostcodeButton);
        savedPostcodesTV = (TextView) findViewById(R.id.savedPostcodesTV);
        postCode = (EditText) findViewById(R.id.postcodeET);
    }

    /**
     * sets the postcode ui invisible
     */
    public void uiForNonUsers() {
        postcodeCheckBox.setVisibility(View.INVISIBLE);
        postcodeSpinner.setVisibility(View.INVISIBLE);
        postcodeCheckBox.setVisibility(View.INVISIBLE);
        searchSavePostcodeButton.setVisibility(View.INVISIBLE);
        savedPostcodesTV.setText("Login to save favourite postcodes");
    }

    /**
     * listener for the spinner
     */
    public class MyOnItemSelectedListener implements AdapterView.OnItemSelectedListener {

        //sets the item selected to the selected string
        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
            selected = parent.getItemAtPosition(pos).toString();
        }

        public void onNothingSelected(AdapterView parent) {
        }
    }

    /**
     * goes to map using the postcode selected from the spinner
     *
     * @param view
     */
    public void goToPostcode(View view) {
        Intent intent = new Intent(this, PostcodeMapsActivity.class);
        intent.putExtra("Postcode", selected);
        startActivity(intent);
    }

    /**
     * deletes postcode
     *
     * @param view
     */
    public void deletePostcode(View view) {
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
//        dbHandler.deletePostcode(selected,username);
        Toast.makeText(getApplicationContext(), "Postcode successfully deleted",
                Toast.LENGTH_SHORT).show();
        getPostcodes();
    }

    /**
     * gets the postcodes from the db and puts them in the spinner
     */
    public void getPostcodes() {
        MyDBHandler myDBHandler = new MyDBHandler(this, null, null, 1);
        ArrayList<String> postcodes = new ArrayList<String>();

        //clears the postcodes arrayList every time the method is called
        postcodes.clear();

        //gets the postcodes from the db using the username of the currently logged in user
        postcodes = myDBHandler.getPostcode(username);
        myDBHandler.close();

        if (postcodes.size() == 0) {

        } else {
            //array adapter to get the postcodes into the spinner
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, postcodes);
            postcodeSpinner.setAdapter(adapter);

            //sets the onItemSelectedListener to get the value from the spinner
            postcodeSpinner.setOnItemSelectedListener(new MyOnItemSelectedListener());
        }

    }

    /**
     * uses the value from the editText to search in the maps activity
     *
     * @param view
     */
    public void toMap(View view) {
        //get postcodes from the editText
        String postcode = postCode.getText().toString();

        //if the postcode editText is empty tell the user to enter a postcode if not go to the maps activity
        if (postcode.equals("")) {
            Toast.makeText(getApplicationContext(), "Please enter a postcode",
                    Toast.LENGTH_SHORT).show();
        } else {
            //if the checkBox is checked save the postcode to the db
            if (postcodeCheckBox.isChecked()) {
                savePostcode();
            }

            Intent intent = new Intent(this, PostcodeMapsActivity.class);
            //put the postcode value into the intent
            intent.putExtra("Postcode", postCode.getText().toString());
            startActivity(intent);

            //update the postcodes
            getPostcodes();
        }
    }

    /**
     * Saves the postcode to the database
     */
    public void savePostcode() {

        //new postcode object for the db
        PostCodes postcode = new PostCodes(username, postCode.getText().toString());
        MyDBHandler myDBHandler = new MyDBHandler(this, null, null, 1);

        //add the postcode to the database
        myDBHandler.addPostcode(postcode);
        myDBHandler.close();
    }


    /**
     * Called when the user clicks the find bars by current location button
     */
    public void onClicks(View view) {
        Intent intent = new Intent(this, BarMapsActivity.class);
        startActivity(intent);
    }
}
