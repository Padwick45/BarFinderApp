package com.example.paddy.barfinderapp2;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Pair;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * controls the postcode map activity
 */
public class PostcodeMapsActivity extends FragmentActivity implements OnMapReadyCallback {

    //objects arrayLists and strings for the class
    private GoogleMap mMap;
    private LatLng latLng;
    private String postCode;
    List<Address> addressList, addressList1;
    ArrayList<Pair<String, String>> barNamesCodes = new ArrayList<Pair<String, String>>();
    ArrayList<Pair<String, String>> barAddressesNumbers = new ArrayList<Pair<String, String>>();
    MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
    ArrayList<String> postcodes = new ArrayList<String>();
    Address address;

    //this will be the first location
    Location location = new Location("thatLocation");


    /**
     * on create set up the map and bring the postcode over
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postcode_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Intent intent = getIntent();
        //gets the postcode from the previous activity
        postCode = intent.getStringExtra("Postcode");
    }


    /**
     * manipulates the map when the map is ready, used to add markers etc.
     *
     * @param googleMap
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.mMap = googleMap;

        //address object
        Address address;

        //if the postcode isn't null then add the markers to the map
        if (postCode != null || !postCode.equals("")) {
            Geocoder geocoder = new Geocoder(this);
            try {

                //this will store the postcode's location
                location = new Location("");
                addressList = geocoder.getFromLocationName(postCode, 1);

                //gets the address from the addressList
                address = addressList.get(0);

                //used to plot the position of the markers
                latLng = new LatLng(address.getLatitude(), address.getLongitude());

                //set the postcodes location
                location.setLatitude(latLng.latitude);
                location.setLongitude(latLng.longitude);

                //at the marker on the location letting the user know where the are
                mMap.addMarker(new MarkerOptions().position(latLng)).setTitle("Postcode location here");

                //move the camera into position
                mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

                //set target and zoom for the camera
                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(latLng).zoom(15).build();

                //use values to zoom in on location with animation
                mMap.animateCamera(CameraUpdateFactory
                        .newCameraPosition(cameraPosition));

                //add bars within 2km of the postcode location
                addBarsToMap();

            } catch (IOException e) {
            }
        }
    }

    /**
     * adds all the bars within 2km of the postcode's location
     */
    public void addBarsToMap() {

        //get arraylist pair of the bar names and postcodes from the db
        barNamesCodes = dbHandler.getBarNamePostcode();

        //get arraylist pair of the bar address and the phone number
        barAddressesNumbers = dbHandler.getBarAddressTelephone();

        //geocoder used to get the geolocation
        Geocoder geocoder = new Geocoder(this);

        try {
            //will be the location of the bar
            Location location1 = new Location("thisLocation");
            //will be the address of the bar
            Address address1;

            //loop to get all the bar info from the database and see if they meet the specification to be shown
            //using markers on the map
            for (int count = 0; count < barNamesCodes.size(); count++) {
                addressList1 = geocoder.getFromLocationName(barAddressesNumbers.get(count).first + "," + barNamesCodes.get(count).first, 1);
                address1 = addressList1.get(0);

                //gets the location info for the second location object
                LatLng latLng1 = new LatLng(address1.getLatitude(), address1.getLongitude());

                //sets the location for the bar
                location1.setLongitude(latLng1.longitude);
                location1.setLatitude(latLng1.latitude);

                //gets distance between the bar and the postcode location
                float distanceInMeters = location.distanceTo(location1);

                //if the distance between the locations is less that 2km add the markers for the bar
                if (distanceInMeters < 2000) {
                    mMap.addMarker(new MarkerOptions()
                            .position(latLng1)
                            .title(barNamesCodes.get(count).second + " ")
                            .icon(BitmapDescriptorFactory
                                    .defaultMarker(BitmapDescriptorFactory.HUE_AZURE)))
                            .setSnippet(barAddressesNumbers.get(count).first + ", " + barAddressesNumbers.get(count).second);
                }
            }


        } catch (IOException e) {

        }
    }


}







