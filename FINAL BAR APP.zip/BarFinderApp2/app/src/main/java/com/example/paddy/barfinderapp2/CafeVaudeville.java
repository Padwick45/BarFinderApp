package com.example.paddy.barfinderapp2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;


public class CafeVaudeville extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cafe_vaudeville);

        //TextView displaying the bar's address
        TextView t = (TextView) findViewById(R.id.cafeVaudevilleAddress);
        //Sets the text of the textview to the bar's address
        t.setText(Html.fromHtml(
                "Address: " +
                        "<a href=\"https://www.google.co.uk/maps/place/Cafe+Vaudeville/@54.5979128,-5.9301569,17z/data=!3m1!4b1!4m2!3m1!1s0x4861085672f6fd93:0xcb23de975ee19976\">" +
                        "The Cafe Vaudeville, Arthur Street, Belfast" +
                        "</a>"));
        //Converts text into a clickable link
        t.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
