package com.example.paddy.barfinderapp2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;


public class RegisterScreen extends AppCompatActivity {

    // declare xml reference variables
    private EditText username, pass1, pass2, email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_screen);
        setUpVars();
    }

    // when the user clicks register button do this
    public void onClick(View view) {

        //gets the values from the editTexts to strings
        String userName = username.getText().toString();
        String password1 = pass1.getText().toString();
        String password2 = pass2.getText().toString();
        String rEmail = email.getText().toString();

        System.out.println("Register clicked");

        //if any of the editTexts are empty then tell the user
        if (userName.equals("") || password1.equals("") || password2.equals("") || rEmail.equals("")) {
            Toast.makeText(getApplicationContext(), "Please fill in every field", Toast.LENGTH_LONG).show();
            return;

        }


        MyDBHandler myDBHandler = new MyDBHandler(this, null, null, 1);
        //get whether the email is in the db
        String emailStatus = myDBHandler.checkEmailStatus(rEmail);
        //get whether the username is in the db
        String usernameStatus = myDBHandler.checkUsernameStatus(userName);
        //close db
        myDBHandler.close();


        //if the confirm password doesn't match the password then tell the user
        if (!password1.equals(password2)) {
            Toast.makeText(getApplicationContext(), "Password does not match", Toast.LENGTH_LONG).show();
            return;
        }
        //if the email is in the db tell the user
        if (emailStatus.equals("found")) {
            Toast.makeText(getApplicationContext(), "Email already registered, try forgot password page", Toast.LENGTH_LONG).show();
            return;
        }
        //if the username is in the db tell the user
        else if (usernameStatus.equals("found")) {
            Toast.makeText(getApplicationContext(), "Username taken, pick different username", Toast.LENGTH_LONG).show();
            return;

        }
        //add the user
        else {
            User user = new User(password1, userName, rEmail);

            //adds user to db
            myDBHandler.addUser(user);
            myDBHandler.close();

            //go to the login screen
            Intent intent = new Intent(this, LoginScreen.class);
            startActivity(intent);
        }
    }


    // gets the references to the xml ids
    private void setUpVars() {
        username = (EditText) findViewById(R.id.registerUsernameET);
        pass1 = (EditText) findViewById(R.id.registerPassword1ET);
        pass2 = (EditText) findViewById(R.id.registerPassword2ET);
        email = (EditText) findViewById(R.id.registerEmailET);
    }


}
