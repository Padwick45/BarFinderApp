package com.example.paddy.barfinderapp2;

/**
 * used to get and set values of a postcode
 */
public class PostCodes {

    // attributes of the class
    private int _id;
    private String _username;
    private String _postCode;

    public PostCodes() {

    }

    /**
     * constructor with args
     *
     * @param username
     * @param postcode
     */
    public PostCodes(String username, String postcode) {
        this._username = username;
        this._postCode = postcode;

    }

    /**
     * get the username
     *
     * @return
     */
    public String get_username() {
        return _username;
    }

    /**
     * set the username
     *
     * @param _username
     */
    public void set_username(String _username) {
        this._username = _username;
    }


    /**
     * get the id
     *
     * @return
     */
    public int get_id() {
        return _id;
    }

    /**
     * set the id
     *
     * @param _id
     */
    public void set_id(int _id) {
        this._id = _id;
    }

    /**
     * get the postcode
     *
     * @return
     */
    public String get_postCode() {
        return _postCode;
    }

    /**
     * set the postcode
     *
     * @param _postCode
     */
    public void set_postCode(String _postCode) {
        this._postCode = _postCode;
    }


}
