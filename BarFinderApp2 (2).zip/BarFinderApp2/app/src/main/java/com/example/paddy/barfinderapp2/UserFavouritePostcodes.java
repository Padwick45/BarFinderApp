package com.example.paddy.barfinderapp2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class UserFavouritePostcodes extends AppCompatActivity {

    private String username;
    private TextView postcodeTV;
    private Spinner postcodeSpinner;
    public String selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_favourite_postcodes);

        Intent startingIntent = getIntent();
        username = startingIntent.getStringExtra("username");
        postcodeSpinner =(Spinner)findViewById(R.id.postcodeSpinner);
        getPostcodes();
        populateSpinner();


    }

    public class MyOnItemSelectedListener implements AdapterView.OnItemSelectedListener {

        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
            selected = parent.getItemAtPosition(pos).toString();
        }

        public void onNothingSelected(AdapterView parent) {
            // Do nothing.
        }
    }

    public void goToPostcode(View view){
        Intent intent = new Intent(this, PostcodeMapsActivity.class);
        intent.putExtra("Postcode", selected);
        startActivity(intent);
    }


    public void getPostcodes(){
        MyDBHandler myDBHandler = new MyDBHandler(this, null, null, 1);
       ArrayList<String> postcodes=new ArrayList<String>();
        postcodes=myDBHandler.getPostcode(username);
       // postcodes.add(0, myDBHandler.getPostcode(username).get(0));

        for(int count=0;count<postcodes.size();count++){

        }

        postcodeTV = (TextView)findViewById(R.id.favouritePostcodesTV);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, postcodes);
        postcodeSpinner.setAdapter(adapter);
        postcodeSpinner.setOnItemSelectedListener(new MyOnItemSelectedListener());

    }

    public void populateSpinner(){




    }
}
