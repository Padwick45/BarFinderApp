package com.example.paddy.barfinderapp2;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;

import com.google.android.gms.auth.GooglePlayServicesAvailabilityException;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;

public class PostcodeMapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    double latitude_start, longitude_start;
    private LatLng latLng;
    private String postCode;
    int PLACE_PICKER_REQUEST;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postcode_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Intent intent = getIntent();
        postCode = intent.getStringExtra("Postcode");

        Toast.makeText(getApplicationContext(), postCode,
                Toast.LENGTH_LONG).show();

    }

    public void locationFromPostCode(String postCode) {


    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {


        List<Address> addressList;

        if (postCode != null || !postCode.equals("")) {
            Geocoder geocoder = new Geocoder(this);
            try {
                addressList = geocoder.getFromLocationName(postCode, 1);
//

                Address address = addressList.get(0);
                LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
                // Toast.makeText(getApplicationContext(), "Wrong username or passwords"+address.toString(),
                //         Toast.LENGTH_LONG).show();

                //       Toast.makeText(getApplicationContext(), "Latitude longitude info" + latLng.toString(),
                //              Toast.LENGTH_LONG).show();
//
                googleMap.addMarker(new MarkerOptions().position(latLng)).setTitle("You are here");


                googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

                // Moving Camera to a Location with animation

                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(latLng).zoom(12).build();

                googleMap.animateCamera(CameraUpdateFactory
                        .newCameraPosition(cameraPosition));

            } catch (IOException e){

            }


        }
                try {
                    try {
                         PLACE_PICKER_REQUEST = 1;
                        PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                        startActivityForResult(builder.build(this), PLACE_PICKER_REQUEST);
                    } catch (GooglePlayServicesRepairableException rep) {

                    }
                }
                catch (GooglePlayServicesNotAvailableException g){
                    {
                        //      // handle exception
                    }



        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PLACE_PICKER_REQUEST) {
            if (resultCode == RESULT_OK) {
                Place place = PlacePicker.getPlace(data, this);
                String toastMsg = String.format("Place: %s", place.getName());
                Toast.makeText(this, toastMsg, Toast.LENGTH_LONG).show();
            }
        }



        }
        //   try {

        //  List<Address> addresses1 = geocoder1.getFromLocationName(postCode, 1);
        //  if (addresses1 != null && !addresses1.isEmpty()) {
        //      Address address1 = addresses1.get(0);
        // Use the address as needed
        //      latitude_start = address1.getLatitude();
        //     longitude_start = address1.getLongitude();
        //     String message = "Latitude: "+address1.getLatitude()+", Longitude: "+address1.getLongitude();
        //    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
//

        //  } else {
        // Display appropriate message when Geocoder services are not available
        //     Toast.makeText(this, "Unable to geocode zipcode", Toast.LENGTH_LONG).show();
        //     latitude_start = 0;
        //      longitude_start = 0;
        //   }

        //  LatLng latLng = new LatLng(latitude_start, longitude_start);

        //   } catch (IOException e) {
        //      // handle exception
        //  }

        //mMap.addMarker(new MarkerOptions().position(new LatLng(currentLatitude, currentLongitude)).title("Current Location"));
        //  MarkerOptions options = new MarkerOptions()
        //      .position(latLng)
        //      .title("I am here!");
        //  mMap.addMarker(options);
        //  mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

        // Moving Camera to a Location with animation

        //  CameraPosition cameraPosition = new CameraPosition.Builder()
        //           .target(latLng).zoom(12).build();

        //   mMap.animateCamera(CameraUpdateFactory
        //          .newCameraPosition(cameraPosition));
        //


    }
   // }



