package com.example.paddy.barfinderapp2;

/**
 * Created by Paddy on 17/04/2016.
 */
public class Bar {

    private int _id;
    private String _barName;
    private String _address;
    private String _postcode;
    private String _phoneNumber;
    private int _startOpenHours;
    private int _endOpenHours;

    public Bar(){

    }

    public Bar(String barName, String address, String postcode, String phoneNumber, int startOpenHours, int endOpenHours){

        this._barName=barName;
        this._address=address;
        this._postcode=postcode;
        this._phoneNumber=phoneNumber;
        this._startOpenHours=startOpenHours;
        this._endOpenHours=endOpenHours;


    }

    public int get_endOpenHours() {
        return _endOpenHours;
    }

    public void set_endOpenHours(int _endOpenHours) {
        this._endOpenHours = _endOpenHours;
    }

    public int get_startOpenHours() {
        return _startOpenHours;
    }

    public void set_startOpenHours(int _startOpenHours) {
        this._startOpenHours = _startOpenHours;
    }


    public String get_address() {
        return _address;
    }

    public void set_address(String _address) {
        this._address = _address;
    }

    public String get_barName() {
        return _barName;
    }

    public void set_barName(String _barName) {
        this._barName = _barName;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String get_phoneNumber() {
        return _phoneNumber;
    }

    public void set_phoneNumber(String _phoneNumber) {
        this._phoneNumber = _phoneNumber;
    }

    public String get_postcode() {
        return _postcode;
    }

    public void set_postcode(String _postcode) {
        this._postcode = _postcode;
    }




}
