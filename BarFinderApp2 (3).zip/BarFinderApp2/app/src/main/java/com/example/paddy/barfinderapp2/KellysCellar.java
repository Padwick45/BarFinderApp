package com.example.paddy.barfinderapp2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

public class KellysCellar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kellys_cellar);

        //TextView displaying the bar's address
        TextView t = (TextView) findViewById(R.id.kellysAddress);
        //Sets the text of the textview to the bar's address
        t.setText(Html.fromHtml(
                "Address: " +
                        "<a href=\"https://www.google.co.uk/maps/place/Kelly's+Cellars/@54.5995119,-5.9343445,17z/data=!3m1!4b1!4m2!3m1!1s0x4861085704b1287f:0x785a0478f7a40b67\">" +
                        "Kelly's Cellars, 30-32 Bank Street, Belfast BT1 1HL, United Kingdom" +
                        "</a>"));
        //Converts text into a clickable link
        t.setMovementMethod(LinkMovementMethod.getInstance());
    }
}

