package com.example.paddy.barfinderapp2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

public class CrownLiquorSaloon extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crown_liquor_saloon);

        //TextView displaying the bar's address
        TextView t = (TextView) findViewById(R.id.crownAddress);
        //Sets the text of the textview to the bar's address
        t.setText(Html.fromHtml(
                "Address: " +
                        "<a href=\"https://www.google.co.uk/maps/place/The+Crown+Liquor+Saloon/@54.5946928,-5.9363562,17z/data=!3m1!4b1!4m2!3m1!1s0x486108f7f82ae92d:0xc684d41e09cf2fff\">" +
                        "The Crown Liquor Saloon, Great Victoria Street, Belfast" +
                        "</a>"));
        //Converts text into a clickable link
        t.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
