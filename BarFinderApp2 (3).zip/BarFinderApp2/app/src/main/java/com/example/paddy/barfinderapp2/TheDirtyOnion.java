package com.example.paddy.barfinderapp2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;
import java.lang.Override;

public class TheDirtyOnion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_dirty_onion);

        //TextView displaying the bar's address
        TextView t = (TextView) findViewById(R.id.dirtyOnionAddress);
        //Sets the text of the textview to the bar's address
        t.setText(Html.fromHtml(
                "Address: " +
                        "<a href=\"https://www.google.co.uk/maps/place/The+Dirty+Onion/@54.6016331,-5.9285032,17z/data=!3m1!4b1!4m2!3m1!1s0x48610853e8ab5d8b:0x1b2f13f9321b6d19\">" +
                        "The Dirty Onion, Hill Street, Belfast" +
                        "</a>"));
        //Converts text into a clickable link
        t.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
