package com.example.paddy.barfinderapp2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ListView;

import java.lang.Override;
import java.util.ArrayList;
import java.util.List;

public class MainActivityTaxi extends AppCompatActivity {

    // Default constructor
    private ListView lvTaxi;
    private TaxiListAdapter adapter;
    private List<Taxi> mTaxiList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_taxi);
       // Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
       // setSupportActionBar(toolbar);

        //ListView used to add taxis
        lvTaxi = (ListView)findViewById(R.id.listview_taxi );
        //Initialising te array
        mTaxiList = new ArrayList<>();

        //Using an array to add the taxi data to be displayed in the listView
        //This will arrange the name, phone number and address correctly to be displayed in the Taxi Finder
        mTaxiList.add(new Taxi(1, "Value Cabs", "02890 809 080", "16 Wellington Park, \nBelfast \nBT9 6DJ"));
        mTaxiList.add(new Taxi(2, "FonaCAB", "02890 333 333", "23 Botanic Avenue, \nBelfast, \nBT7 1JG"));
        mTaxiList.add(new Taxi(3, "Knockabs", "02890 658 100", "241 Upper Newtownards Road, \nBelfast, \nBT4 3JF"));
        mTaxiList.add(new Taxi(4, "Castle Cabs", "02890 241 111", "26 King Street, \nBelfast, \nBT1 1HU"));
        mTaxiList.add(new Taxi(5, "24/7 Taxis", "02890 247 247", "217 Lisburn Road, \nBelfast, \nBT9 7EG"));
        mTaxiList.add(new Taxi(6, "Kiwk-Kabs", "02890 457 979", "173 Ardenlee Avenue, \nBelfast, \nBT6 0AE"));
        mTaxiList.add(new Taxi(7, "East Belfast Taxis", "02890 456 456", "285 Newtownards Road, \nBelfast, \nBT4 1AG"));
        mTaxiList.add(new Taxi(8, "Gransha Taxis", "02890 602 092", "81b Glen Road, \nBelfast, \nBT11 8BD"));
        mTaxiList.add(new Taxi(9, "Eagle Taxis", "02890 300 333", "185a Ormeau Road, \nBelfast, \nBT7 3GQ"));
        mTaxiList.add(new Taxi(10, "Max Cabs", "02890 653 030", "2 Grampian Avenue, \nBelfast, \nBT4 3AB"));

        //Initialise the adapter for adding taxis to the listView
        adapter = new TaxiListAdapter(getApplicationContext(), mTaxiList);
        lvTaxi.setAdapter(adapter);
    }

}