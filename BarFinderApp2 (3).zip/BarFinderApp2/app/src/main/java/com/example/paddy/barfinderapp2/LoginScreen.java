package com.example.paddy.barfinderapp2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;

import java.util.ArrayList;

/**
 * Class to control the login screen
 */
public class LoginScreen extends AppCompatActivity {

    /**
     * Here the variables are declared to which will be used to reference
     * the views from the xml.
     */
    private EditText username;
    private EditText password;
    private Button login;
    private Button register;
    private TextView numberOfRemainingLoginAttempts;
    int numberOfRemainingLoginAttempts1 = 3;

    /**
     * called on create, sets up the vars, click listeners and the activity
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);
        // calls the setUpVars method
        setUpVars();

        /**
         * Register click handler
         */
        register.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View register) {
                registerLink();
            }
        });

        /**
         * This reacts to the clicking or pressing of the login button, if the button
         * has been clicked then the 'testLoginInput' method is called
         */
        login.setOnClickListener(new OnClickListener() {
            //Specifies what happens with the login button is clicked
            public void onClick(View login) {
                //calls the testLoginInput method
                testLoginInput();
            }

        });
    }


    /**
     * this method tests the user's input against the database records to see if their username
     * matches the password, if it doesn't the user is shown a message
     */
    public void testLoginInput() {

        addThoseBars();

        //the username and password to be tested
        String userName = username.getText().toString();
        String passWord = password.getText().toString();

        //gets db handler
        MyDBHandler myDBHandler = new MyDBHandler(this, null, null, 1);

        //finds the password related to the username in the db
        String storedPassword = myDBHandler.getLoginVerification(userName);

        //close the db
        myDBHandler.close();

        //if the password is null the account doesn't exist
        if (storedPassword == null) {
            Toast.makeText(getApplicationContext(), "Account doesn't exist",
                    Toast.LENGTH_SHORT).show();
        }
        //if the entered password equals the stored password then the user can log in
        else if (passWord.equals(storedPassword)) {
            //A short toast is displayed telling the user they have been successful
            Toast.makeText(getApplicationContext(), "You have logged in successfully",
                    Toast.LENGTH_SHORT).show();
            //The method mainLink() is called here
            mainLink();


        }
        // If the if and elseif conditions have not been met then this part is used.
        else {
            // Shows a short toast telling the user they got the password wrong
            Toast.makeText(getApplicationContext(), "password",
                    Toast.LENGTH_SHORT).show();
            // decrements the attempts remaining by 1
            numberOfRemainingLoginAttempts1--;
            // sets the number of attempts remaining text view to the new value
            numberOfRemainingLoginAttempts.setText(Integer.toString(numberOfRemainingLoginAttempts1));

            //Tests to see if the number of remaining login attempts equals 0
            if (numberOfRemainingLoginAttempts1 == 0) {
                // disables the use of the login button
                login.setEnabled(false);
            }
        }
    }

    /**
     * This method accesses the main menu
     */
    public void mainLink() {
        //new intent used to get to the main menu
        Intent intent = new Intent(this, MainActivityHome.class);
        //passes the username into the intent to be carried to the next activity
        intent.putExtra("username", username.getText().toString());
        //start the next activity
        startActivity(intent);
    }

    /**
     * This method accesses the register screen
     */
    public void registerLink() {
        Intent intent = new Intent(this, RegisterScreen.class);
        startActivity(intent);
    }

    /**
     * forgot password click to get to the forgot password page
     * @param view
     */
    public void forgotPasswordLink(View view) {
        Intent intent = new Intent(this, ForgotPasswordActivity.class);
        startActivity(intent);
    }


    /**
     * This method connects the variables declared in this class with
     * views in the xml code, this allows the xml views to be manipulated in the java
     * code
     */
    private void setUpVars() {
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        login = (Button) findViewById(R.id.LoginButton);
        numberOfRemainingLoginAttempts = (TextView) findViewById(R.id.numberOfRemainingLoginAttempts);
        numberOfRemainingLoginAttempts.setText(Integer.toString(numberOfRemainingLoginAttempts1));
        register = (Button) findViewById(R.id.registerButton);
    }


    private ArrayList<Bar> bars = new ArrayList<Bar>();


    public void addThoseBars() {
        Bar bar1 = new Bar("Laverys", "12 Bradbury Pl, Belfast", "BT7 1RS", "02890871106");
        Bar bar2 = new Bar("The Botannic Inn", "23-27 Malone Rd, Belfast ", "BT9 6RU", "02890509740");
        Bar bar3 = new Bar("The Parlour", "2-4 Elmwood Ave, Belfast", "BT9 6AY", "02890686970");
        Bar bar4 = new Bar("Ryan's Bar and Restaurant", "116 Lisburn Rd, Belfast", "BT9 6AH", "02890509850");
        Bar bar5 = new Bar("Cuckoo", "149 Lisburn Rd, Belfast", "BT9 7AJ", "02890667776");
        Bar bar6 = new Bar("The Eglantine", "32 Malone Rd, Belfast", "BT9 5BQ", "02890381994");
        Bar bar8 = new Bar("Benedicts of Belfast", "7-21 Bradbury Pl, Belfast", "BT7 1RQ", "02890591999");
        Bar bar9 = new Bar("Cutters Wharf", "4 Lockview Rd, Belfast", "BT9 5FJ", "02890805100");
        Bar bar10 = new Bar("The Belfast Empire Music Hall", "42 Botanic Ave, Belfast", "BT7 1JQ", "02890249276");
        Bar bar11 = new Bar("McHughs Bar and Restaurant", "29-31 Queen's Square, Belfast", "BT1 3FG", "02890509999");
        Bar bar12 = new Bar("The Crown Liquor Saloon", "46 Great Victoria St, Belfast", "BT2 7BA", "02890243187");
        Bar bar13 = new Bar("Duke of York", "7-11 Commercial Ct, Belfast", "BT1 2NB", "02890241062");
        Bar bar14 = new Bar("The Hedgehog & Bucket", "538 Oldpark Rd, Belfast ", "BT14 6QJ", "02890721000");
        Bar bar15 = new Bar("The John Hewitt Bar", "51 Donegall St, Belfast", "BT1 2FH", "02890233768");
        Bar bar16 = new Bar("The House", "12 Stranmillis Rd, Belfast", "BT9 5AA", "02890682266");
        Bar bar17 = new Bar("Claudines", "Dukes At Queens, University Rd, Belfast", "BT7 1NN", "02890236666");
        Bar bar18 = new Bar("The Graduate", "130 Ormeau Rd, Belfast", "BT7 2EB", "02890238825");
        Bar bar19 = new Bar("Wellington Park Hotel", "21 Malone Rd, Belfast", "BT9 6RU", "02890381111");
        Bar bar20 = new Bar("Queen's Students' Union", "75-79 University Rd, Belfast", "BT7 1NF", "02890973726");
        Bar bar21 = new Bar("The Chelsea", "346 Lisburn Rd, Belfast", " BT9 6GH", "02890687177");
        Bar bar22 = new Bar("Kings Head, Belfast", "829 Lisburn Rd, Belfast", "BT9 7GY", "02890509950");
        Bar bar23 = new Bar("Brewbot", "451 Ormeau Rd, Belfast ", "BT7 3GQ", "No number available");
        Bar bar24 = new Bar("Pavilion Bar", "296-298 Ormeau Rd, Belfast", "BT7 2GB", "02890283283");
        Bar bar25 = new Bar("The Dirty Onion", "3 Hill St, Belfast", "BT1 2LA", "02890243712");
        Bar bar26 = new Bar("Spaniard", "3 Skipper St, Belfast ", "BT1 2DZ", "02890232448");
        Bar bar27 = new Bar("The Northern Whig", "2-10 Bridge St, Belfast", "BT1 1LU", "02890509888");
        Bar bar28 = new Bar("Muriel's Cafe Bar", "12-14 Church Ln, Belfast", "BT1 4QN", "028 9033 2445");

        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
        dbHandler.addBar(bar1);
        dbHandler.addBar(bar2);
        dbHandler.addBar(bar3);

        dbHandler.addBar(bar5);
        dbHandler.addBar(bar6);
        dbHandler.addBar(bar11);
        dbHandler.addBar(bar8);
        dbHandler.addBar(bar9);

        dbHandler.addBar(bar12);
        dbHandler.addBar(bar13);

        dbHandler.addBar(bar14);
        dbHandler.addBar(bar15);
        dbHandler.addBar(bar16);

        dbHandler.addBar(bar17);
        dbHandler.addBar(bar18);
        dbHandler.addBar(bar19);
        dbHandler.addBar(bar20);
        dbHandler.addBar(bar21);

        dbHandler.addBar(bar22);
        //  dbHandler.addBar(bar23);
        dbHandler.addBar(bar24);
        // dbHandler.addBar(bar25);
        dbHandler.addBar(bar26);
        // dbHandler.addBar(bar27);
        dbHandler.addBar(bar28);
        dbHandler.close();

    }
}

