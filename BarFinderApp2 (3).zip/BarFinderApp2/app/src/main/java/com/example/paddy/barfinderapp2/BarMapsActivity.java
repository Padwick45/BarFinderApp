package com.example.paddy.barfinderapp2;

import android.Manifest;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.util.Pair;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Maps activity used to search for bars by the user's location
 */
public class BarMapsActivity extends FragmentActivity implements
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener {

    public static final String TAG = BarMapsActivity.class.getSimpleName();

    //location object used for distance measurement
    private Location locations;

    /*
     * Define a request code to send to Google Play services
     * This code is returned in Activity.onActivityResult
     */
    private final static int CONNECTION_FAILURE_RESOLUTION_REQUEST = 9000;

    private GoogleMap mMap; // Might be null if Google Play services APK is not available.

    private GoogleApiClient mGoogleApiClient;
    private LocationRequest mLocationRequest;

    /**
     * This method is called when the activity is started
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bar_maps);

        //sets up the map if needed
        setUpMapIfNeeded();

        //build the googleApiClient
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        // Create the LocationRequest object
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(10 * 1000)        // 10 seconds, in milliseconds
                .setFastestInterval(1 * 1000); // 1 second, in milliseconds
    }

    /**
     * Called on resume
     */
    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
        mGoogleApiClient.connect();
    }

    /**
     * called on pause
     */
    @Override
    protected void onPause() {
        super.onPause();

        if (mGoogleApiClient.isConnected()) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
            mGoogleApiClient.disconnect();
        }
    }

    /**
     * Tests to see if the map needs set up, if it does then it sets up the map
     */
    private void setUpMapIfNeeded() {
        // Checks that the map has not already been instantiated
        if (mMap == null) {
            // Tries to get the map object from the support fragment
            mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();
            // Checks if the map object has been created, if it has the map is set up
            if (mMap != null) {
                setUpMap();
            }
        }
    }

    /**
     *
     */
    private void setUpMap() {

    }

    /**
     * Used to handle the user's current location, sets out a marker to show the current location
     *
     * @param location
     */
    private void handleUserLocation(Location location) {
        Log.d(TAG, location.toString());

        //This is used so that addBarsToMap() can access the user's current location
        this.locations = location;

        //gets the from the location object current latitude and longitude
        double currentLatitude = location.getLatitude();
        double currentLongitude = location.getLongitude();

        //new latlng to be used to plot a marker
        LatLng latLng = new LatLng(currentLatitude, currentLongitude);

        //adds a marker at the users location with a message
        mMap.addMarker(new MarkerOptions().position(latLng).title("Current Location").title("You are here!"));

        //moves the camera to the location
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

        //cameraPosition object used to zoom
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(latLng).zoom(15).build();

        //animation to zoom in on the location
        mMap.animateCamera(CameraUpdateFactory
                .newCameraPosition(cameraPosition));

        //adds the bars to the map
        addBarsToMap();
    }

    /**
     * adds the bars to the map if they are within 2km of the users location
     */
    public void addBarsToMap() {

        //declares all the lists we need
        List<Address> addressList, addressList1;
        ArrayList<Pair<String, String>> barNamesCodes = new ArrayList<Pair<String, String>>();
        ArrayList<Pair<String, String>> barAddressesNumbers = new ArrayList<Pair<String, String>>();

        //gets the dbHandler
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);

        //arrayList pair of bar names and postcodes
        barNamesCodes = dbHandler.getBarNamePostcode();

        //arrayList pair of bar addresses and numbers
        barAddressesNumbers = dbHandler.getBarAddressTelephone();

        //new geocoder object
        Geocoder geocoder = new Geocoder(this);

        try {
            //address and location set up
            Address address1;
            Location location1 = new Location("");

            //loop to get all the bar info from the database and see if they meet the specification to be shown
            //using markers on the map
            for (int count = 0; count < barNamesCodes.size(); count++) {
                addressList1 = geocoder.getFromLocationName(barAddressesNumbers.get(count).first + "," + barNamesCodes.get(count).first, 1);
                address1 = addressList1.get(0);

                //gets the location info for the second location object
                location1.setLatitude(address1.getLatitude());
                location1.setLongitude(address1.getLongitude());

                //finds the distance between the user's location and the bar's location
                float distanceInMeters = locations.distanceTo(location1);

                //if the bar is less than 2km away from the user show the bar details on the map
                if (distanceInMeters < 2000) {
                    LatLng latLng1 = new LatLng(address1.getLatitude(), address1.getLongitude());

                    //marker showing the bar on the map, set the colour to blue, set the message to the bar details
                    mMap.addMarker(new MarkerOptions()
                            .position(latLng1)
                            .title(barNamesCodes.get(count).second + " ")
                            .icon(BitmapDescriptorFactory
                                    .defaultMarker(BitmapDescriptorFactory.HUE_AZURE)))
                            .setSnippet(barAddressesNumbers.get(count).first + ", " + barAddressesNumbers.get(count).second);
                }
            }
        } catch (IOException e) {
        }
    }


    /**
     * Do this on connection(handles the user's location
     *
     * @param bundle
     */
    @Override
    public void onConnected(Bundle bundle) {

        //test the permissions
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        Location location = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (location == null) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        } else {
            handleUserLocation(location);
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }


    /**
     * if connection fails try to resolve
     *
     * @param connectionResult
     */
    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {

        if (connectionResult.hasResolution()) {
            try {
                // Start an Activity that tries to resolve the error
                connectionResult.startResolutionForResult(this, CONNECTION_FAILURE_RESOLUTION_REQUEST);
            } catch (IntentSender.SendIntentException e) {
                e.printStackTrace();
            }
        } else {
            /*
             * If no resolution is available, display a dialog to the
             * user with the error.
             */
            Log.i(TAG, "Location services connection failed with code " + connectionResult.getErrorCode());
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        handleUserLocation(location);
    }
}
