package com.example.paddy.barfinderapp2;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import java.lang.Override;

public class MainActivityHome extends AppCompatActivity {

    //Declares the variables for the buttons
    //to be used on the home screen
    ImageButton button1, button2, button3, button4;
    public String username;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        Intent startingIntent = getIntent();
        //get the username through the intent
        username = startingIntent.getStringExtra("username");

        //if the username isn't null welcome the user back
        if(username!=null) {
            Toast.makeText(getApplicationContext(), "Welcome back " + username,
                    Toast.LENGTH_LONG).show();
        }

        //Sets the click function for each of the four buttons on the home screen
        button1 = (ImageButton) findViewById(R.id.imageButton);
        button2 = (ImageButton) findViewById(R.id.imageButton2);
        button3 = (ImageButton) findViewById(R.id.imageButton3);
        button4 = (ImageButton) findViewById(R.id.imageButton4);

        //Sets up the click function for button 1
       button1.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

               Intent intent = new Intent(MainActivityHome.this, SearchBars.class);
                intent.putExtra("username", username);
             //  Starts the click function when button is pressed
               startActivity(intent);
            }
        });

        //Sets up the click function for button 2
        button2.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

                Intent intent = new Intent(MainActivityHome.this,MainActivityBars.class);
                startActivity(intent);
            }
        });

        //Sets up the click function for button 3
        button3.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

                Intent intent = new Intent(MainActivityHome.this,MainActivityTaxi.class);
                startActivity(intent);
            }
        });
    }

    /**
     * on click the method goes to the login page
     * @param view
     */
    public void goToLogin(View view){
        Intent intent = new Intent(this, LoginScreen.class);
        startActivity(intent);

    }

}



