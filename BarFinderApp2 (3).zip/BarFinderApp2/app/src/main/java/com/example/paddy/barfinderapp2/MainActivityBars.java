package com.example.paddy.barfinderapp2;


import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.lang.Math;
import java.lang.Override;
import java.lang.String;
import java.lang.System;
import java.util.Random;


public class MainActivityBars extends AppCompatActivity implements SensorEventListener {

    //Declaring the sensor manager variable
    private SensorManager senSensorManager;
    //Declaring the sensor variable
    private Sensor senAccelerometer;
    //Variable storing the time of the last update
    private long lastUpdate = 0;
    //Variable for the last position X, Y and Z axis
    private float last_x, last_y, last_z;
    //The maximum shake threshold
    private static final int SHAKE_THRESHOLD = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_bars);

        //Initializing Sensor manager.
        // Using getSystemService to get a reference to a service of the system by passing the name of the service
        senSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        // Gettng a reference to the system's accelerometer
        senAccelerometer = senSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        //Registering the sensor
        senSensorManager.registerListener(this, senAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);


        //ListView to display the recommended bars
        ListView lv = (ListView) findViewById(R.id.barListView);

        //Array containing the recommended bars
        String[] rBars = new String[]{"Kelly’s Cellars", "White’s Tavern", "Crown Liquor Salon", "Café Vaudeville", "Duke of York", "The Dirty Onion", "The Hudson", "The Filthy Quarter"};

        //Adapter to manipulate listView
        ListAdapter theAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, rBars);

        //Setting the listview adapter
        lv.setAdapter(theAdapter);

        //On item click listener to open a recommended bar activity when list item is clicked
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Gets the positions of the bars in the array rBars
                String rBars = String.valueOf(parent.getItemAtPosition(position));

                //Opens the activity for Kellys cellar
                if (position == 0) {
                    Intent myIntent = new Intent(view.getContext(), KellysCellar.class);
                    startActivityForResult(myIntent, 0);

                    //Opens the activity for Whites Tavern
                } else if (position == 1) {
                    Intent myIntent = new Intent(view.getContext(), WhitesTavern.class);
                    startActivityForResult(myIntent, 1);

                    //Opens the activity for Crown liquor saloon
                } else if (position == 2) {
                    Intent myIntent = new Intent(view.getContext(), CrownLiquorSaloon.class);
                    startActivityForResult(myIntent, 2);

                    //Opens the activity for Cafe Vaudeville
                } else if (position == 3) {
                    Intent myIntent = new Intent(view.getContext(), CafeVaudeville.class);
                    startActivityForResult(myIntent, 3);

                    //Opens the activity for Duke of york
                } else if (position == 4) {
                    Intent myIntent = new Intent(view.getContext(), DukeOfYork.class);
                    startActivityForResult(myIntent, 4);

                    //Opens the activity for The Dirty onion
                } else if (position == 5) {
                    Intent myIntent = new Intent(view.getContext(), TheDirtyOnion.class);
                    startActivityForResult(myIntent, 5);

                    //Opens the activity for The Hudson
                } else if (position == 6) {
                    Intent myIntent = new Intent(view.getContext(), TheHudson.class);
                    startActivityForResult(myIntent, 6);

                    //Opens the activity for The Filthy quarter
                } else if (position == 7) {
                    Intent myIntent = new Intent(view.getContext(), TheFilthyQuarter.class);
                    startActivityForResult(myIntent, 7);
                }
            }
        });
    }

    /**
     * Method to detect the shake gesture.
     *
     * @param sensorEvent
     */
    public void onSensorChanged(SensorEvent sensorEvent) {
        //Getting a reference to the sensor instance
        Sensor mySensor = sensorEvent.sensor;


        //Checking the reference is to the correct sensor type
        if (mySensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            //Getting the sensors value for the X axis
            float x = sensorEvent.values[0];
            //Getting the sensors value for the Y axis
            float y = sensorEvent.values[1];
            //Getting the sensors value for the Z axis
            float z = sensorEvent.values[2];

            //Storing the device's current time
            long currentTime = System.currentTimeMillis();

            //Ensuring at least 100 milliseconds have passed since the time onSensorChanged was invoked
            if ((currentTime - lastUpdate) > 100) {
                long diffTime = (currentTime - lastUpdate);
                lastUpdate = currentTime;

                //Using the Math class to calculate the device's speed
                float speed = Math.abs(x + y + z - last_x - last_y - last_z) / diffTime * 10000;

                //When the speed is greater than the shake threshold the getRandomBar method is invoked
                if (speed > SHAKE_THRESHOLD) {
                    getRandomBar();
                }

                last_x = x;
                last_y = y;
                last_z = z;
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    /**
     * Unregister's the sensor when the app hibernates
     */
    @Override
    protected void onPause() {
        super.onPause();
        senSensorManager.unregisterListener(this);
    }

    /**
     * Registers the application again when the app resumes
     */
    @Override
    protected void onResume() {
        super.onResume();
        senSensorManager.registerListener(this, senAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    /**
     * Method to get a random bar
     */

    private void getRandomBar() {

        //Geting a random number
        Random randNumber = new Random();
        int iNumber = randNumber.nextInt(7) + 1;


        //If the random number is equal to 1 the Kellys cellar page is opened
        if (iNumber == 1) {
            Intent myIntent = new Intent(this, KellysCellar.class);
            startActivityForResult(myIntent, 0);

            //If the random number is equal to 2 the Whites Tavern page is opened
        } else if (iNumber == 2) {
            Intent myIntent = new Intent(this, WhitesTavern.class);
            startActivityForResult(myIntent, 1);

            //If the random number is equal to 3 the Crown liquor saloon page is opened
        } else if (iNumber == 3) {
            Intent myIntent = new Intent(this, CrownLiquorSaloon.class);
            startActivityForResult(myIntent, 2);

            //If the random number is equal to 4 the Cafe Vaudeville page is opened
        } else if (iNumber == 4) {
            Intent myIntent = new Intent(this, CafeVaudeville.class);
            startActivityForResult(myIntent, 3);

            //If the random number is equal to 5 the Duke of York page is opened
        } else if (iNumber == 5) {
            Intent myIntent = new Intent(this, DukeOfYork.class);
            startActivityForResult(myIntent, 4);

            //If the random number is equal to 6 the Dirty Onion page is opened
        } else if (iNumber == 6) {
            Intent myIntent = new Intent(this, TheDirtyOnion.class);
            startActivityForResult(myIntent, 5);

            //If the random number is equal to 7 the Hudson page is opened
        } else if (iNumber == 7) {
            Intent myIntent = new Intent(this, TheHudson.class);
            startActivityForResult(myIntent, 6);

            //If the random number is equal to 8 the Filthy Quarter page is opened
        } else if (iNumber == 8) {
            Intent myIntent = new Intent(this, TheFilthyQuarter.class);
            startActivityForResult(myIntent, 7);
        }
    }
}