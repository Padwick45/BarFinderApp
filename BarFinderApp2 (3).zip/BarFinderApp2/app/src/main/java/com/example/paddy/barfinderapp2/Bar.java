package com.example.paddy.barfinderapp2;

/**
 * Used to create a bar object for storing and getting bar attributes
 */
public class Bar {

    //declare attributes of the bar as variables
    private int _id;
    private String _barName;
    private String _address;
    private String _postcode;
    private String _phoneNumber;

    /**
     * Default constructor for the bar
     *
     * @param barName
     * @param address
     * @param postcode
     * @param phoneNumber
     */
    public Bar(String barName, String address, String postcode, String phoneNumber) {

        this._barName = barName;
        this._address = address;
        this._postcode = postcode;
        this._phoneNumber = phoneNumber;


    }

    /**
     * Gets bar address
     *
     * @return
     */
    public String get_address() {
        return _address;
    }

    /**
     * Sets bar address
     *
     * @param _address
     */
    public void set_address(String _address) {
        this._address = _address;
    }

    /**
     * Gets bar name
     *
     * @return
     */
    public String get_barName() {
        return _barName;
    }

    /**
     * Sets bar name
     *
     * @param _barName
     */
    public void set_barName(String _barName) {
        this._barName = _barName;
    }

    /**
     * Gets bar id
     *
     * @return
     */
    public int get_id() {
        return _id;
    }

    /**
     * Sets bar id
     *
     * @param _id
     */
    public void set_id(int _id) {
        this._id = _id;
    }

    /**
     * Gets bar phone number
     *
     * @return
     */
    public String get_phoneNumber() {
        return _phoneNumber;
    }

    /**
     * Sets bar phonenumber
     *
     * @param _phoneNumber
     */
    public void set_phoneNumber(String _phoneNumber) {
        this._phoneNumber = _phoneNumber;
    }

    /**
     * gets bar postcode
     *
     * @return
     */
    public String get_postcode() {
        return _postcode;
    }

    /**
     * sets bar postcode
     *
     * @param _postcode
     */
    public void set_postcode(String _postcode) {
        this._postcode = _postcode;
    }


}
