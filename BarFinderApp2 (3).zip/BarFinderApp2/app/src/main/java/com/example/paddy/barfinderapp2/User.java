package com.example.paddy.barfinderapp2;

/**
 * user class used to get and set info on users
 */
public class User {

    //vars for the attributes of the user
    private int _id;
    private String _username;
    private String _password;
    private String _email;

    public User(){

    }

    /**
     * constructor with args
     * @param password
     * @param username
     * @param email
     */
    public User ( String password, String username, String email){
        this._password = password;
        this._username = username;
        this._email = email;
    }

    /**
     * Gets the email
     * @return
     */
    public String get_email() {
        return _email;
    }

    /**
     * sets the email
     * @param _email
     */
    public void set_email(String _email) {
        this._email = _email;
    }

    /**
     * gets the id
     * @return
     */
    public int get_id() {
        return _id;
    }

    /**
     * sets the id
     * @param _id
     */
    public void set_id(int _id) {
        this._id = _id;
    }

    /**
     * gets the password
     * @return
     */
    public String get_password() {
        return _password;
    }

    /**
     * sets the password
     * @param _password
     */
    public void set_password(String _password) {
        this._password = _password;
    }

    /**
     * gets the username
     * @return
     */
    public String get_username() {
        return _username;
    }

    /**
     * sets the username
     * @param _username
     */
    public void set_username(String _username) {
        this._username = _username;
    }

}
