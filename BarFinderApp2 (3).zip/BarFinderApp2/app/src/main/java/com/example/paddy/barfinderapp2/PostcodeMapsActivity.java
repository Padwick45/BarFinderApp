package com.example.paddy.barfinderapp2;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Pair;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * controls the postcode map activity
 */
public class PostcodeMapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private LatLng latLng;
    private String postCode;
    List<Address> addressList, addressList1;
    ArrayList<Pair<String,String>> barNamesCodes = new ArrayList<Pair<String,String>>();
    ArrayList<Pair<String,String>> barAddressesNumbers = new ArrayList<Pair<String,String>>();
    MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);

    ArrayList<String> postcodes = new ArrayList<String>();
    // postcodes = dbHandler.getBar();
    Address address;
    Location location = new Location("thatLocation");




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postcode_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Intent intent = getIntent();
        postCode = intent.getStringExtra("Postcode");

        Toast.makeText(getApplicationContext(), postCode,
                Toast.LENGTH_LONG).show();

    }

    public void locationFromPostCode(String postCode) {


    }



    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.mMap = googleMap;



       // ArrayList<String> postCodes = new ArrayList<String>();
      //  postCodes.add()
        ArrayList<Pair<String,String>> barNamesCodes = new ArrayList<Pair<String,String>>();
        ArrayList<Pair<String,String>> barAddressesNumbers = new ArrayList<Pair<String,String>>();
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
        barNamesCodes = dbHandler.getBarNamePostcode();
        barAddressesNumbers=dbHandler.getBarAddressTelephone();
       ArrayList<String> postcodes = new ArrayList<String>();
      // postcodes = dbHandler.getBar();
        Address address;



        if (postCode != null || !postCode.equals("")) {
            Geocoder geocoder = new Geocoder(this);
            try {


                location = new Location("");
                addressList = geocoder.getFromLocationName(postCode, 1);



                address = addressList.get(0);

                latLng = new LatLng(address.getLatitude(), address.getLongitude());
                location.setLatitude(latLng.latitude);
                location.setLongitude(latLng.longitude);





                mMap.addMarker(new MarkerOptions().position(latLng)).setTitle("You are here");




                mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

                // Moving Camera to a Location with animation

                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(latLng).zoom(15).build();

                mMap.animateCamera(CameraUpdateFactory
                        .newCameraPosition(cameraPosition));
                addBarsToMap();

            } catch (IOException e) {

            }
        }
    }

    public void addBarsToMap(){


        barNamesCodes = dbHandler.getBarNamePostcode();
        barAddressesNumbers=dbHandler.getBarAddressTelephone();






        Geocoder geocoder = new Geocoder(this);
        try {
            Location location1 = new Location("thisLocation");
            Address address1;
            for (int count = 0; count < barNamesCodes.size(); count++) {
                addressList1 = geocoder.getFromLocationName(barAddressesNumbers.get(count).first+","+barNamesCodes.get(count).first, 1);
                System.out.println(count);
                address1 = addressList1.get(0);
                LatLng latLng1 = new LatLng(address1.getLatitude(), address1.getLongitude());
                double lat1 = latLng1.latitude;
                double long1 = latLng1.longitude;

                System.out.println(lat1+"     "+long1);
                location1.setLongitude(latLng1.longitude);
                location1.setLatitude(latLng1.latitude);
                float distanceInMeters=location.distanceTo(location1);
                System.out.println(distanceInMeters);
                if(distanceInMeters<2000) {
                    mMap.addMarker(new MarkerOptions()
                            // Set the Marker's position
                            .position(latLng1)
                                    // Set the title of the Marker's information window
                            .title(barNamesCodes.get(count).second + " ")
                                    // Set the color for the Marker
                            .icon(BitmapDescriptorFactory
                                    .defaultMarker(BitmapDescriptorFactory.HUE_AZURE)))
                            .setSnippet(barAddressesNumbers.get(count).first + ", " + barAddressesNumbers.get(count).second);

                }



            }



        } catch (IOException e) {

        }
    }






        }







