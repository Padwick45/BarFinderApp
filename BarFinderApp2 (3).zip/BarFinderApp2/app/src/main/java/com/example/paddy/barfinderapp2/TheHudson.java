package com.example.paddy.barfinderapp2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;
import java.lang.Override;

public class TheHudson extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_hudson);

        //TextView displaying the bar's address
        TextView t = (TextView) findViewById(R.id.hudsonAddress);
        //Sets the text of the textview to the bar's address
        t.setText(Html.fromHtml(
                "Address: " +
                        "<a href=\"https://www.google.co.uk/maps/place/The+Hudson+Bar/@54.6018429,-5.9342918,17z/data=!3m1!4b1!4m2!3m1!1s0x48610850d303a17b:0x3298ddb52fb11493\">" +
                        "The Hudson Bar, Gresham Street, Belfast" +
                        "</a>"));
        //Converts text into a clickable link
        t.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
