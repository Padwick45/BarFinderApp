package com.example.paddy.barfinderapp2;

import java.lang.String; /**
 * Created by Aaron on 17/04/2016.
 */
//Class used for setting up the gets and sets for the array adapter
public class Taxi {

    // Default constructor
    private int id;
    private String name;
    private String phone;
    private String address;

    // Constructor with args
    public Taxi(int id, String name, String phone, String address) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.address = address;
    }

    // Getters and setters
    // Gets the ID
    public int getId() {
        return id;
    }

    // Sets the ID to be displayed in the MainActivityTaxi.java
    public void setId(int id) {
        this.id = id;
    }

    // Gets the name of the taxi
    public String getName() {
        return name;
    }

    // Sets the name of the taxi
    public void setName(String name) {
        this.name = name;
    }

    // Gets the phone number of the taxi company
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    // Gets the address of the taxi company
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
