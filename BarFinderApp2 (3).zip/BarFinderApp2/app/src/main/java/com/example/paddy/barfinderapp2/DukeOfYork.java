package com.example.paddy.barfinderapp2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

public class DukeOfYork extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_duke_of_york);

        //TextView displaying the bar's address
        TextView t = (TextView) findViewById(R.id.dukeOfYorAddress);
        //Sets the text of the textview to the bar's address
        t.setText(Html.fromHtml(
                "Address: " +
                        "<a href=\"https://www.google.co.uk/maps/place/Duke+Of+York/@54.6018308,-5.9298515,17z/data=!3m1!4b1!4m2!3m1!1s0x48610853f8c7c8cf:0xdeee055a81e36743\">" +
                        "Duke Of York, Commercial Court, Belfast" +
                        "</a>"));
        //Converts text into a clickable link
        t.setMovementMethod(LinkMovementMethod.getInstance());
    }
}
